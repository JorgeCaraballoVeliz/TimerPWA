import { LitElement, html, css } from 'lit';
import { TimerPartComponent } from './TimerPartComponent.js';

export class TimerComponent extends LitElement {
    static properties = {
        seconds: { type: Number },
        minutes: { type: Number},
        hours: { type: Number},
        days: { type: Number},
        format: { type: String},
        base: { type: Number, attribute: 'start' },
        end: { type: Number },
        join: { type: String }
        
    }

    static styles = css`
        :host {
            display: flex;
            justify-content: var(--timer-component-justify-content, center);
        }

        .timer-component_join {
            padding: var(--timer-component-join-padding);
        }
    `;

    constructor() {
        super();
        this.base = 0;
        this.format = 'HH:MM:SS';
        this.join = ':';
        this.finishEvent = new CustomEvent('finishTimer', { bubbles: true, composed: true });
        this.playEvent = new CustomEvent('playTimer', { bubbles: true, composed: true });
        this.pauseEvent = new CustomEvent('pauseTimer', { bubbles: true, composed: true });
        this.resetEvent = new CustomEvent('resetTimer', { bubbles: true, composed: true });
    }

    connectedCallback() {
        super.connectedCallback();
        this._resetValues();
    }

    disconnectedCallback() {
        this._finish();
        super.disconnectedCallback();
    }

    render() {
        return html`
            ${this._timerTemplate()}
        `;
    }

    get isFinished() {
        if (this.count === 0) {
            return true;
        } else if (this.end && this.count === this.end) {
            return true;
        }
    }

    startTimer() {
        //console.log("he llegado");
        if (!this.interval) {
            this.interval = setInterval(() => {
                if (this.isFinished) {
                    this._finish();
                } else {
                    this.count--;
                    this._setTime();
                    if (this.isFinished) this._finish();
                }
    
                console.log("segundos");
            }, 1000);
            this.dispatchEvent(this.playEvent);
        }
    }

    resetTimer() {
        this._clearInterval();
        this._resetValues();
        this.dispatchEvent(this.resetEvent);
    }

    pauseTimer() {
        this._clearInterval();
        this.dispatchEvent(this.pauseEvent);
    }

    _joinTemplate() {
        return html`
            <span class="timer-component_join">${this.join}</span>
        `;
    }

    _timerTemplate() {
        const formatArr = this.format.split(':');
        const time = formatArr.map((part) => {
            if (part.includes('D')) return this.days;
            if (part.includes('H')) return this.hours;
            if (part.includes('M')) return this.minutes;
            if (part.includes('S')) return this.seconds;
        });

        const template = html`${time.map((value, index) => html`
            <time-part-component value="${value}" format="${formatArr[index]}"></time-part-component>
            ${index < time.length - 1 ? this._joinTemplate() : ''}
        `)}`;

        return template;
    }

    _setTime() {
        const secondsT = this.count % 60;
        const minutesT = Math.floor(this.count / 60) % 60;
        const hoursT = Math.floor(this.count / 3600);
        const daysT = Math.floor(this.count / 86400);
        if (secondsT !== this.seconds) this.seconds = secondsT;
        if (minutesT !== this.minutes) this.minutes = minutesT;
        if (hoursT !== this.hours) this.hours = hoursT;
        if (daysT !== this.days) this.days = daysT;
    }

    _resetValues() {
        this.seconds = 0;
        this.minutes = 0;
        this.hours = 0;
        this.days = 0;
        this.count = this.base;
        this._setTime();
    }

    _clearInterval() {
        clearInterval(this.interval);
        this.interval = null;
    }

    _finish() {
        this._clearInterval();
        this.dispatchEvent(this.finishEvent);
    }
}
customElements.define('timer-component', TimerComponent);